# Local Meeting Intelligence Artifact Pack

Purpose: build a private, local, evidence-preserving meeting-analysis pipeline for corporate call recordings.

Core design:
- 4000 GPU A: exhaustive structured fact gathering from canonical transcript chunks.
- 4000 GPU B: independent validation, claim checking, and missed-detail scanning.
- 96GB GPU: heavy critical thinker / synthesis builder that creates the final 19-section architectural report from curated evidence, not from raw transcript alone.
- CPU/control plane: deterministic orchestration, schema validation, evidence storage, retrieval, report assembly, and audit logging.

Primary model decision:
- 96GB builder candidate: Mistral Medium 3.5 128B, quantized.
- 96GB fallback/speed candidate: Mistral Small 4 119B NVFP4.
- 4000 extractor candidate: Qwen3.6-27B quantized.
- 4000 validator candidate: Gemma 4 31B IT NVFP4 if it fits, otherwise Gemma 4 26B-A4B or Mistral Small 3.2 24B.
- TP-2 across the 4000s is not the default. Use it only for targeted extraction benchmarks or if one-card model/context quality is inadequate.

Included artifacts:
- local_meeting_intelligence_model_matrix.xlsx: role-by-role model matrix, evidence sources, benchmark rubric, and backlog.
- docs/architecture_plan.md: pipeline and hardware architecture.
- docs/model_evidence_register.md: researched evidence and interpretation by model/component.
- configs/pipeline_config.yaml: candidate model/runtime/endpoint layout.
- configs/benchmark_manifest.yaml: golden transcript benchmark plan.
- configs/docker_compose_skeleton.yml: local service skeleton.
- json_schemas/*.schema.json: evidence, report section, and validation result schemas.
- prompts/*.txt: extractor, merger, 96GB builder, and validator prompts.

Operational note:
The models should not choose tools. Python orchestration should call fixed extractors, validators, retrievers, and builders. Models emit structured records; the control plane validates, retries, stores, and assembles.
